#pragma once

#ifndef __XIR_CAST_H__
#define __XIR_CAST_H__

#include "./c_unistring.h"
#include "./c_location.h"
#include "./c_array.h"
#include "./c_point.h"
#include "./c_rect.h"

#endif // !__XIR_CAST_H__

