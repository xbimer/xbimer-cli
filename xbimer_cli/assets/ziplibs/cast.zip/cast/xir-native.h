#pragma once

#ifndef __XIR_NATIVE_H__
#define __XIR_NATIVE_H__

#include "./n_lock.h"




#endif // !__XIR_NATIVE_H__
