#pragma once

#ifndef __CAST_AC24_H__
#define __CAST_AC24_H_

#endif // !__CAST_AC24_H_
